-How the application works
-Launch the Exe application, the startWindow app
-then click on the start Phishing Analysis 
-then a new window will pop up trying to load a certain url 
- input the web address you want to Analyse and click on the Analyse button
NOTE: Your address must be in the format : http://theaddress.com without any quote,
- Wait for the result  of the analysis of the phishing website
- If the address is not accessible you get a Network Error message 
- If the address is a legitimate website, it tells you afterwards, then proceed to the webpage 
- If the webpage contains phishing attacks, it tells you and warns you, click on show details to view the source code of the page, thenn click on 
	ok to continue, it will then load the page for you to verify. 
-
You can test the application with some  phishing websites i have put online
-http://www.paypaiaccount.tk/
-http://khellbazar.com/sve/Validation/login.php?cmd=login_submit&i
You can get more phishing websites to test from : http://www.phishtank.com